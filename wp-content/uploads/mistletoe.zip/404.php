<?php get_header(); ?>

<section class="section">

  <article class="article">

    <div class="post-text">
      <h2 class="post-title"><?php _e('Error 404 - Not Found',sf); ?></h2>
    </div>

    <p><?php if (get_option("sf_404_page") == true) { echo get_option("sf_404_page"); } else { echo "404 Not Found"; } ?></p>
    
    <?php get_search_form();?>
    
    <div class="left">
      <h3><?php _e('Archives by month:',sf); ?></h3>
      <ul>
        <?php wp_get_archives('type=monthly'); ?>
      </ul>
    </div>
       
    <div class="right">
      <h3><?php _e('Archives by category:',sf); ?></h3>
      <ul>
        <?php wp_list_cats('sort_column=name'); ?>
      </ul>
    </div>

    <div class="clearfix">&nbsp;</div>

  </article><!-- .article -->

</section><!-- .section -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>