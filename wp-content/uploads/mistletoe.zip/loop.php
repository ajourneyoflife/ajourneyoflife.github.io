<?php
//============================================================================
if ( ( function_exists( 'get_post_format' ) && 'gallery' == get_post_format( $post->ID ) ) ) :
//============================================================================
?>
  <article class="article">

    <div class="post-text post-format-gallery">
      <h2 class="post-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
      <ul class="post-meta">
        <li class="post-date"><?php the_time(__('jS F Y')) ?></li>
        <li class="post-category"><?php the_category(', ') ?></li>
      </ul>
    </div>
    <?php echo do_shortcode('[gallery link="file" columns="3"]'); ?>
    <footer class="post-footer">
      <ul class="post-info-meta">
        <li class="post-comment"><?php comments_popup_link(__('No comment',sf), __('1 comment',sf), __('% comments',sf)); ?></li>
        <li>
          <a href="https://twitter.com/share" class="twitter-share-button" data-url="<?php the_permalink() ?>" data-count="horizontal" data-via="<?php if (get_option("sf_twitter")) { echo get_option("sf_twitter"); } else { echo "zhngdesign"; } ?>">Tweet</a><script type="text/javascript" src="//platform.twitter.com/widgets.js"></script>
        </li>
        <li>
          <div id="fb-root"></div>
          <div class="fb-like" data-href="<?php the_permalink() ?>" data-send="true" data-layout="button_count" data-width="150" data-show-faces="false"></div>
        </li>
      </ul>
    </footer><!-- .post-footer -->
 
  </article><!-- .article -->
<?php
//============================================================================
elseif ( ( function_exists( 'get_post_format' ) && 'aside' == get_post_format( $post->ID ) )  ) :
//============================================================================
?>
  <article class="article">

    <div class="post-text post-format-aside">
      <h2 class="post-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
      <ul class="post-meta">
        <li class="post-date"><?php the_time(__('jS F Y')) ?></li>
        <li class="post-category"><?php the_category(', ') ?></li>
      </ul>
    </div>
    <?php the_content(); ?>

    <footer class="post-footer">
      <ul class="post-info-meta">
        <li class="post-comment"><?php comments_popup_link(__('No comment',sf), __('1 comment',sf), __('% comments',sf)); ?></li>
        <li>
          <a href="https://twitter.com/share" class="twitter-share-button" data-url="<?php the_permalink() ?>" data-count="horizontal" data-via="<?php if (get_option("sf_twitter")) { echo get_option("sf_twitter"); } else { echo "zhngdesign"; } ?>">Tweet</a><script type="text/javascript" src="//platform.twitter.com/widgets.js"></script>
        </li>
        <li>
          <div id="fb-root"></div>
          <div class="fb-like" data-href="<?php the_permalink() ?>" data-send="true" data-layout="button_count" data-width="150" data-show-faces="false"></div>
        </li>
      </ul>
    </footer><!-- .post-footer -->
 
  </article><!-- .article -->
<?php
//============================================================================
elseif ( ( function_exists( 'get_post_format' ) && 'image' == get_post_format( $post->ID ) )  ) :
//============================================================================
?>
  <article class="article">

    <div class="post-text post-format-image">
      <h2 class="post-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
      <ul class="post-meta">
        <li class="post-date"><?php the_time(__('jS F Y')) ?></li>
        <li class="post-category"><?php the_category(', ') ?></li>
      </ul>
    </div>

    <?php 
      $args = array(
      'order'          => 'ASC',
      'post_type'      => 'attachment',
      'post_parent'    => $post->ID,
      'post_mime_type' => 'image',
      'post_status'    => null,
      'numberposts'    => -1,
      );
      $attachments = get_posts($args);
      if ($attachments) {
        foreach ($attachments as $attachment) {
        echo wp_get_attachment_image($attachment->ID, 'large', false, false);
        }
      }
    ?>

    <footer class="post-footer">
      <ul class="post-info-meta">
        <li class="post-comment"><?php comments_popup_link(__('No comment',sf), __('1 comment',sf), __('% comments',sf)); ?></li>
        <li>
          <a href="https://twitter.com/share" class="twitter-share-button" data-url="<?php the_permalink() ?>" data-count="horizontal" data-via="<?php if (get_option("sf_twitter")) { echo get_option("sf_twitter"); } else { echo "zhngdesign"; } ?>">Tweet</a><script type="text/javascript" src="//platform.twitter.com/widgets.js"></script>
        </li>
        <li>
          <div id="fb-root"></div>
          <div class="fb-like" data-href="<?php the_permalink() ?>" data-send="true" data-layout="button_count" data-width="150" data-show-faces="false"></div>
        </li>
      </ul>
    </footer><!-- .post-footer -->
 
  </article><!-- .article -->
<?php
//============================================================================
else :
//============================================================================
?>
  <article class="article">

    <div class="post-text post-format-standard">
      <h2 class="post-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
      <ul class="post-meta">
        <li class="post-date"><?php the_time(__('jS F Y')) ?></li>
        <li class="post-category"><?php the_category(', ') ?></li>
      </ul>
    </div>
    <?php the_content(); ?>

    <footer class="post-footer">
      <ul class="post-info-meta">
        <li class="post-comment"><?php comments_popup_link(__('No comment',sf), __('1 comment',sf), __('% comments',sf)); ?></li>
        <li>
          <a href="https://twitter.com/share" class="twitter-share-button" data-url="<?php the_permalink() ?>" data-count="horizontal" data-via="<?php if (get_option("sf_twitter")) { echo get_option("sf_twitter"); } else { echo "zhngdesign"; } ?>">Tweet</a><script type="text/javascript" src="//platform.twitter.com/widgets.js"></script>
        </li>
        <li>
          <div id="fb-root"></div>
          <div class="fb-like" data-href="<?php the_permalink() ?>" data-send="true" data-layout="button_count" data-width="150" data-show-faces="false"></div>
        </li>
      </ul>
    </footer><!-- .post-footer -->
 
  </article><!-- .article -->
<?php
//============================================================================
endif;
//============================================================================
?>