<?php get_header(); ?>

<section class="section">

  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
  <article class="article">

    <div class="post-text">
      <h2 class="post-title"><?php the_title(); ?></h2>
    </div>

    <?php the_content(); ?>

  </article><!-- .article -->
  <?php endwhile; endif; ?>

</section><!-- .section -->

<?php if(get_post_meta($post->ID, "sf_wide", true)) {} else { echo get_sidebar(); } ?>

<?php get_footer(); ?>