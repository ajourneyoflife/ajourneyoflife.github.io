<!DOCTYPE html>
<!--[if IE 6]><html id="ie6" <?php language_attributes(); ?>><![endif]-->
<!--[if IE 7]><html id="ie7" <?php language_attributes(); ?>><![endif]-->
<!--[if IE 8]><html id="ie8" <?php language_attributes(); ?>><![endif]-->
<!--[if !(IE 6) | !(IE 7) | !(IE 8)  ]><!--><html <?php language_attributes(); ?>><!--<![endif]-->
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width" />
<title><?php global $page, $paged; wp_title('|', true, 'right'); bloginfo('name'); $site_description = get_bloginfo('description', 'display'); if ( $site_description && ( is_home() || is_front_page() ) ) echo " | $site_description"; if ($paged >= 2 || $page >= 2) echo ' | ' . sprintf(__('Page %s'), max( $paged, $page )); ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<link rel="shortcut icon" href="<?php bloginfo('stylesheet_directory'); ?>/images/favicon.gif?<?php echo date('l jS \of F Y h:i:s A'); ?>" />
<link href="<?php bloginfo('stylesheet_url'); ?>?<?php echo date('l jS \of F Y h:i:s A'); ?>" media="screen" type="text/css" rel="stylesheet" />
<link href="<?php bloginfo('template_url'); ?>/styles/mobile.css?<?php echo date('l jS \of F Y h:i:s A'); ?>" media="screen and (max-width: 480px)" rel="stylesheet" type="text/css" />
<link href="<?php bloginfo('template_url'); ?>/styles/device.css?<?php echo date('l jS \of F Y h:i:s A'); ?>" media="screen and (min-width: 481px) and (max-width: 960px)" rel="stylesheet" type="text/css" />
<link href="<?php bloginfo('template_url'); ?>/styles/common.css?<?php echo date('l jS \of F Y h:i:s A'); ?>" media="screen and (min-width: 961px)" rel="stylesheet" type="text/css" />
<link href="<?php bloginfo('template_url'); ?>/js/uniform.css" media="screen" type="text/css" rel="stylesheet" />
<link href="http://fonts.googleapis.com/css?family=Muli:400,400italic|Delius+Swash+Caps|Meddon" media="all" type="text/css" rel="stylesheet" />
<!--[if lt IE 7]><script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE7.js"></script><![endif]-->
<!--[if lt IE 8]><script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE8.js"></script><![endif]-->
<!--[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
<?php if (is_singular() && get_option('thread_comments')) wp_enqueue_script('comment-reply'); wp_head(); ?>
<?php wp_enqueue_script("jquery"); ?>
</head>
<body>

<header class="header">

  <nav class="nav">
    <?php if (function_exists('wp_nav_menu') ) { wp_nav_menu('theme_location=top_menu&container_class=menu&show_home=1'); } else {?>
    <ul>
      <?php wp_list_pages('title_li='); ?>
    </ul>
    <?php } ?>
  </nav><!-- .nav -->

  <?php if( is_home() || is_front_page() ) { ?>
    <h1><a href="<?php echo get_option('home'); ?>" class="header-title"><?php bloginfo('name'); ?></a></h1>
  <?php } else { ?>
    <h5><a href="<?php echo get_option('home'); ?>" class="header-title"><?php bloginfo('name'); ?></a></h5>
  <?php } ?>

</header><!-- .header -->

<div class="container">