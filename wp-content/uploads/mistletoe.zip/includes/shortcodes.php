<?php
// =================================
// Split content left/right
// =================================
function column_left($atts, $content = null) {
  return '<div class="left">'.do_shortcode($content).'</div>';
}
function column_right($atts, $content = null) {
  return '<div class="right">'.do_shortcode($content).'</div><div class="clearfix">&nbsp;</div>';
}
add_shortcode('left', 'column_left');
add_shortcode('right', 'column_right');

// =================================
// Split content 3 columns
// =================================
function column_1($atts, $content = null) {
  return '<div class="col1">'.do_shortcode($content).'</div>';
}
function column_2($atts, $content = null) {
  return '<div class="col2">'.do_shortcode($content).'</div>';
}
function column_3($atts, $content = null) {
  return '<div class="col3">'.do_shortcode($content).'</div><div class="clearfix">&nbsp;</div>';
}
add_shortcode('col1', 'column_1');
add_shortcode('col2', 'column_2');
add_shortcode('col3', 'column_3');

// =================================
// Tooltip
// =================================
function tooltip($atts, $content = null) {
  extract(shortcode_atts(
    array(
    "text" => null
    ), $atts)
  );
  return '<span class="tooltip" title="'.$text.'">'.do_shortcode($content).'</span>';
}
add_shortcode('tooltip', 'tooltip');

// =================================
// Break line
// =================================
function line() {
  return '<hr class="line" />';
}
add_shortcode('line', 'line');

// =================================
// Warning box
// =================================
function warning($atts, $content = null) {
  return '<div class="warning">'.do_shortcode($content).'</div><div class="clearfix">&nbsp;</div>';
}
add_shortcode('warning', 'warning');

// =================================
// Querstion box
// =================================
function question($atts, $content = null) {
  return '<div class="question">'.do_shortcode($content).'</div><div class="clearfix">&nbsp;</div>';
}
add_shortcode('question', 'question');

// =================================
// Disclaimer box
// =================================
function disclaim($atts, $content = null) {
  return '<div class="disclaim">'.do_shortcode($content).'</div><div class="clearfix">&nbsp;</div>';
}
add_shortcode('disclaim', 'disclaim');

// =================================
// Button
// =================================
function button_code($atts, $content = null) {
  extract(shortcode_atts(
    array(
    "url" => "http://"
    ), $atts)
  );
  return '<a href="'.$url.'" class="post-button">'.do_shortcode($content).'</a>';
}
add_shortcode('button', 'button_code');

// =================================
// Thickbox
// =================================
function thickbox($atts, $content = null) {
  extract(shortcode_atts(
    array(
    "name" => "NAME",
    "title" => "TITLE",
    "url" => "URL",
    "width" => "WIDTH",
    "height" => "HEIGHT",
    ), $atts)
  );
  return '<a class="thickbox" title="'.$title.'" href="'.$url.'?keepThis=true&amp;TB_iframe=true&amp;height='.$height.'&amp;width='.$width.'">'.$name.'</a>';
}
add_shortcode('lightbox', 'thickbox');

// =================================
// Accordion
// =================================
function accordion_code($atts, $content = null) {
  extract(shortcode_atts(
    array(
    "title" => "TITLE"
    ), $atts)
  );
  return '<div class="accordion-wrap"><div class="accordion-title">'.$title.'</div><div class="accordion-content">'.do_shortcode($content).'</div></div>';
}
add_shortcode('accordion', 'accordion_code');

// =================================
// YouTube
// =================================
function youtube_code($atts) {
  extract(shortcode_atts(
    array(
    "id" => "VIDEO_ID",
    "title" => "VIDEO TITLE",
    "width" => "640",
    "height" => "390",
    ), $atts)
  );
  return '<iframe title="' .$title. '" width="' .$width. '" height="' .$height. '" src="http://www.youtube.com/embed/' .$id. '" frameborder="0" allowfullscreen></iframe>';
}
add_shortcode('youtube', 'youtube_code');

// =================================
// Vimeo
// =================================
function vimeo_code($atts) {
  extract(shortcode_atts(
    array(
    "id" => "VIDEO_ID",
    "width" => "640",
    "height" => "390",
    ), $atts)
  );
  return '<iframe src="http://player.vimeo.com/video/' .$id. '" width="' .$width. '" height="' .$height. '" frameborder="0"></iframe>';
}
add_shortcode('vimeo', 'vimeo_code');

// =================================
// SWF flash
// =================================
function swf_code($atts) {
  extract(shortcode_atts(
  array(
  "url" => "http://",
  "width" => "580",
  "height" => "360",
  ),$atts)
  );
  return '
  <script type="text/javascript">swfobject.registerObject("swfContent", "9.0.0", "expressInstall.swf");</script>
  <object id="swfContent" width="'.$width.'" height="'.$height.'">
  <param name="movie" value="'.$url.'" />
  <!--[if !IE]>--><object type="application/x-shockwave-flash" data="' .$url. '" width="'.$width.'" height="'.$height.'"><!--<![endif]-->
  <h1>Alternative content</h1>
  <p><a href="http://www.adobe.com/go/getflashplayer"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Get Adobe Flash player" /></a></p>
  <!--[if !IE]>--></object><!--<![endif]-->
  </object>
  ';
}
add_shortcode('swf', 'swf_code');

// =================================
// GMap
// =================================
function google_map($atts) {
  extract(shortcode_atts(
    array(
    "lat" => "0.000",
    "long" => "0.000",
    "address" => "ADDRESS",
    "name" => "NAME",
    "postcode" => "57000",
    "width" => "350",
    "height" => "350",
    ), $atts)
  ); ?>

<script type="text/javascript"> 
function initialize(address, num, zoom) {
  var geo = new google.maps.Geocoder(),
    latlng = new google.maps.LatLng(<?php echo $lat; ?>, <?php echo $long; ?>),
    myOptions = {
      'zoom': zoom,
      center: latlng,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    },
    map = new google.maps.Map(document.getElementById("<?php echo $name; ?>"), myOptions);
				  	
    geo.geocode( { 'address': address}, function(results, status) {
      if (status == google.maps.GeocoderStatus.OK) {
      map.setCenter(results[0].geometry.location);
      var marker = new google.maps.Marker({
        map: map, 
        position: results[0].geometry.location
      });
      } else {
    // status
    }
  });
}

jQuery(function($){
  initialize("<?php echo $address; ?>",<?php echo $postcode; ?>,15);
});

</script>
<?php

return '<div id="'.$name.'" style="display:block;width:'.$width.'px;height:'.$height.'px;">&nbsp;</div><div class="clearfix">&nbsp;</div>';

}

add_shortcode('map', 'google_map');

// =================================
// Contact form
// =================================
function contactForm( $atts, $content = null)	{
  // gives access to the plugin's base directory
  extract( shortcode_atts( array(
    'email' => get_bloginfo('admin_email'),
    'subject' => "Subject",
    'message' => "Message",
    'url' => get_bloginfo('template_url')
  ), $atts ) );
  $content .= '
  <script type="text/javascript">
    var $j = jQuery.noConflict();
    $j(window).load(function(){
    $j("#contact-form").submit(function() {
      // validate and process form here
      var str = $j(this).serialize();
        $j.ajax({
        type: "POST",
        url: "'.$url.'/includes/sendmail.php",
        data: str,
        success: function(msg){
        $j("#contact-note").ajaxComplete(function(event, request, settings)
          {
          if(msg == "OK") // Message Sent? Show the Thank You message and hide the form
            {
            result = "'.$message.'";
            $j("#contact-message").slideUp();
            }
            else
            {
            result = msg;
            }
          $j(this).html(result);
          });
        }
      });
    return false;
      });
    });
  </script>';
 
  // now we put all of the HTML for the form into a PHP string
  $content .= '<div id="contact-message">';
  $content .= '<form id="contact-form" action="">';
  $content .= '<input name="to_email" type="hidden" id="to_email" value="' . $email . '"/>';
  $content .= '<input name="subject" type="hidden" id="subject" value="' . $subject . '"/>';
  $content .= '<input name="name" type="text" class="uniform contact-form-text" id="name" title="Name" />';
  $content .= '<input name="email" type="text" class="uniform contact-form-text" id="email" title="Email" />';
  $content .= '<textarea rows="" cols="" class="uniform contact-form-textarea" name="message" title="Message"></textarea>';
  $content .= '<input type="submit" value="Submit" class="uniform contact-form-button" id="contact-submit" />';
  $content .= '</form>';
  $content .= '</div><!--#contact-message-->';
  $content .= '<div id="contact-note"></div><!--notification area used by jQuery/Ajax -->';
  return $content;
}

add_shortcode('contact', 'contactForm');
