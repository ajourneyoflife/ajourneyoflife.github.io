(function() {
  tinymce.create('tinymce.plugins.sf', {
    init : function(ed, url) {

      ed.addButton('2columns', {
        title : '2 Columns',
        image : url+'/editor_imgs/2col.png',
        onclick : function() {
          ed.selection.setContent('[left]' + ed.selection.getContent() + '[/left]<br />[right][/right]');
        }
      });

      ed.addButton('3columns', {
        title : '3 Columns',
        image : url+'/editor_imgs/3col.png',
        onclick : function() {
          ed.selection.setContent('[col1]' + ed.selection.getContent() + '[/col1]<br />[col2][/col2]<br />[col3][/col3]');
        }
      });

      ed.addButton('boxw', {
        title : 'Warning box',
        image : url+'/editor_imgs/boxw.png',
        onclick : function() {
          ed.selection.setContent('[warning]' + ed.selection.getContent() + '[/warning]');
        }
      });

      ed.addButton('boxd', {
        title : 'Disclaim box',
        image : url+'/editor_imgs/boxd.png',
        onclick : function() {
          ed.selection.setContent('[disclaim]' + ed.selection.getContent() + '[/disclaim]');
        }
      });

      ed.addButton('boxq', {
        title : 'Question box',
        image : url+'/editor_imgs/boxq.png',
        onclick : function() {
          ed.selection.setContent('[question]' + ed.selection.getContent() + '[/question]');
        }
      });

      ed.addButton('tooltip', {
        title : 'Tooltip',
        image : url+'/editor_imgs/tooltip.png',
        onclick : function() {
          ed.selection.setContent('[tooltip text="TOOLTIP TEXT"]' + ed.selection.getContent() + '[/tooltip]');
        }
      });

      ed.addButton('button', {
        title : 'Button',
        image : url+'/editor_imgs/button.png',
        onclick : function() {
          ed.selection.setContent('[button url="URL"]' + ed.selection.getContent() + '[/button]');
        }
      });

      ed.addButton('accordion', {
        title : 'Accordion',
        image : url+'/editor_imgs/accordion.png',
        onclick : function() {
          ed.selection.setContent('[accordion title="TITLE"]' + ed.selection.getContent() + '[/accordion]');
        }
      });

      ed.addButton('email', {
        title : 'Contact Email',
        image : url+'/editor_imgs/email.png',
        onclick : function() {
          ed.selection.setContent('[contact email="YourEmail" subject="EmailSubject" message="SentMessage"]');
        }
      });

    },
    createControl : function(n, cm) {
      return null;
    },
    getInfo : function() {
      return {
        longname : "simplyFramework Shortcodes",
        author : 'Andrew Wong',
        authorurl : 'http://www.simplywp.net',
        infourl : 'http://www.simplywp.net',
        version : "1.0.11"
      };
    }

  });

  tinymce.PluginManager.add('sf', tinymce.plugins.sf);

})();