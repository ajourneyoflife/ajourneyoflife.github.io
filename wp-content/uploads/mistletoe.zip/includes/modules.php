<?php
// =================================
// Post format
// =================================
add_theme_support( 'post-formats', array( 'aside', 'gallery','image' ) );

// =================================
// Menu location
// =================================
register_nav_menu('top_menu', 'Top Menu');

// =================================
// Remove auto format
// =================================
function my_formatter($content) {
	$new_content = '';
	$pattern_full = '{(\[raw\].*?\[/raw\])}is';
	$pattern_contents = '{\[raw\](.*?)\[/raw\]}is';
	$pieces = preg_split($pattern_full, $content, -1, PREG_SPLIT_DELIM_CAPTURE);

	foreach ($pieces as $piece) {
		if (preg_match($pattern_contents, $piece, $matches)) {
			$new_content .= $matches[1];
		} else {
			$new_content .= wptexturize(wpautop($piece));
		}
	}

	return $new_content;
}
remove_filter('the_content', 'wpautop');
remove_filter('the_content', 'wptexturize');
add_filter('the_content', 'my_formatter', 99);

// =================================
// Visual editor stylesheet
// =================================
add_editor_style('/styles/editor.css');

// =================================
// Shortcode in excerpt
// =================================
add_filter('the_excerpt', 'do_shortcode');

// =================================
// Shortcode in widget
// =================================
add_filter('widget_text', 'do_shortcode');

// =================================
// Clickable link in content
// =================================
add_filter('the_content', 'make_clickable');

// =================================
// Remove version generator
// =================================
remove_action('wp_head', 'wp_generator');

// =================================
// Add "Home" in menu
// =================================
function home_page_menu( $args ) {
  $args['show_home'] = true;
  return $args;
}
add_filter( 'wp_page_menu_args', 'home_page_menu' );

// =================================
// Change admin panel footer
// =================================
function my_footer_text() {
  echo "<a href=\"http://www.simplywp.net\">Website Design by simplyWP</a>";
} 
add_filter('admin_footer_text', 'my_footer_text');

// =================================
// Change login/logout logo
// =================================
function my_login_head() {
  echo '<style type="text/css">h1 a { background-image: url('.get_bloginfo('template_directory').'/images/custom_logo.gif) !important; }</style>';
}
add_action('login_head', 'my_login_head');

// =================================
// Comment spam, prevention
// =================================
function check_referrer() {
  if (!isset($_SERVER['HTTP_REFERER']) || $_SERVER['HTTP_REFERER'] == "") {
    wp_die( __('Please enable referrers in your browser.') );
  }
}
add_action('check_comment_flood', 'check_referrer');

// =================================
// Custom comment style
// =================================
function comment_style($comment, $args, $depth) {
$GLOBALS['comment'] = $comment; ?>
<li <?php comment_class(); ?>>
  <article class="comment-content" id="comment-<?php comment_ID(); ?>">
    <div class="comment-meta">
    <?php echo get_avatar($comment, $size = '32'); ?>
    <?php printf(__('<h6>%s</h6>'), get_comment_author_link()) ?>
    <small><?php printf( __('%1$s at %2$s'), get_comment_date(), get_comment_time()) ?></small>
    </div>
  <?php if ($comment->comment_approved == '0') : ?><em><?php _e('Your comment is awaiting moderation.') ?></em><br /><?php endif; ?>
  <?php comment_text() ?>
  <?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
  </article>
<?php }

// =================================
// Add internal lightbox
// =================================
function add_themescript(){
if(!is_admin()){
  wp_enqueue_script('jquery');
  wp_enqueue_script('thickbox',null,array('jquery'));
  }
}

function wp_thickbox_script() {
$url = get_bloginfo('template_directory');
?>
<script type="text/javascript">
if ( typeof tb_pathToImage != 'string' )
{
  var tb_pathToImage = "<?php echo get_bloginfo('url').'/wp-includes/js/thickbox'; ?>/loadingAnimation.gif";
}
if ( typeof tb_closeImage != 'string' )
{
  var tb_closeImage = "<?php echo get_bloginfo('url').'/wp-includes/js/thickbox'; ?>/tb-close.png";
}
</script>
<?php
  wp_enqueue_style('thickbox.css', '/'.WPINC.'/js/thickbox/thickbox.css', null, '1.0');
}


add_action('init','add_themescript');
add_action('wp_head', 'wp_thickbox_script');

// =================================
// Add slimbox
// =================================
define("IMAGE_FILETYPE", "(bmp|gif|jpeg|jpg|png)", true);

function slimbox_css() {
$url = get_bloginfo('template_directory');
?>
<link href="<?php echo $url; ?>/js/lightbox/css/slimbox2.css" rel="stylesheet" type="text/css" media="screen" />
<?php }

function slimbox_script() {
$url = get_bloginfo('template_directory');
?>
<script type="text/javascript" src="<?php echo $url; ?>/js/lightbox/lightbox.js"></script>
<?php }

function slimbox_replace($string) {
$pattern = '/(<a(.*?)href="([^"]*.)'.IMAGE_FILETYPE.'"(.*?)><img)/ie';
$replacement = 'stripslashes(strstr("\2\5","rel=") ? "\1" : "<a\2href=\"\3\4\"\5 rel=\"slimbox\"><img")';
return preg_replace($pattern, $replacement, $string);
}

function add_slimbox_rel( $attachment_link ) {
$attachment_link = str_replace( 'a href' , 'a rel="slimbox-cats" href' , $attachment_link );
return $attachment_link;
}

add_action('wp_head', 'slimbox_css');
add_action('wp_footer', 'slimbox_script');
add_filter('the_content', 'slimbox_replace');
add_filter( 'wp_get_attachment_link' , 'add_slimbox_rel' );

// =================================
// Breadcrumb
// =================================
function get_breadcrumb() {
  $space = '&raquo;';
  $name = 'Home'; //text for the 'Home' link
  $before = '<span class="current">';
  $after = '</span>';
    if ( !is_home() && !is_front_page() || is_paged() ) {
      echo '<div class="breadcrumb">'; 
      global $post;
        $home = get_bloginfo('url');
      echo '<a href="' . $home . '">' . $name . '</a> ' . $space . ' ';

if ( is_category() ) {
global $wp_query;
  $cat_obj = $wp_query->get_queried_object();
  $thisCat = $cat_obj->term_id;
  $thisCat = get_category($thisCat);
  $parentCat = get_category($thisCat->parent);
if ($thisCat->parent != 0) echo(get_category_parents($parentCat, TRUE, ' ' . $space . ' '));
  echo $before . 'Archive by category &#39;';
  single_cat_title();
  echo '&#39;' . $after;

} elseif ( is_day() ) {

  echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $space . ' ';
  echo '<a href="' . get_month_link(get_the_time('Y'),get_the_time('m')) . '">' . get_the_time('F') . '</a> ' . $space . ' ';
  echo $before . get_the_time('d') . $after;

} elseif ( is_month() ) {

  echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $space . ' ';
  echo $before . get_the_time('F') . $after;

} elseif ( is_year() ) {

  echo $before . get_the_time('Y') . $after;

} elseif ( is_single() && !is_attachment() ) {

    if(get_post_type() != 'post') {
      $post_type = get_post_type_object(get_post_type());
      $slug = $post_type->rewrite;
      echo $post_type->labels->singular_name;
      echo '&nbsp;';
      echo $space;
      echo '&nbsp;';
      echo $currentBefore;
      the_title();
      echo $currentAfter;
    } else {
      $cat = get_the_category();
      $cat = $cat[0];
      echo get_category_parents($cat, TRUE, ' ' . $space . ' ');
      echo $currentBefore;
      the_title();
      echo $currentAfter;
    }

} elseif ( !is_single() && !is_page() && get_post_type() != 'post') {

  $post_type = get_post_type_object(get_post_type());
  echo $currentBefore;
  echo $post_type->labels->singular_name;
  echo $currentAfter;
  echo '&nbsp;';
  echo $space;
  echo '&nbsp;';
  echo $currentBefore;
    the_title();
  echo $currentAfter;


} elseif ( is_page() && !$post->post_parent ) {

  echo $before;
  the_title();
  echo $after;

} elseif ( is_page() && $post->post_parent ) {

  $parent_id= $post->post_parent;
  $breadcrumbs = array();
    while ($parent_id) {
  $page = get_page($parent_id);
  $breadcrumbs[] = '<a href="' . get_permalink($page->ID) . '">' . get_the_title($page->ID) . '</a>';
  $parent_id= $page->post_parent;
    }
  $breadcrumbs = array_reverse($breadcrumbs);
  foreach ($breadcrumbs as $crumb) echo $crumb . ' ' . $space . ' ';
  echo $before;
  the_title();
  echo $after;

} elseif ( is_search() ) {

  echo $before . 'Search results for &#39;' . get_search_query() . '&#39;' . $after;

} elseif ( is_tag() ) {

  echo $before . 'Posts tagged &#39;';
  single_tag_title();
  echo '&#39;' . $after;

} elseif ( is_author() ) {

  global $author;
    $userdata = get_userdata($author);
    echo $before . 'Articles posted by ' . $userdata->display_name . $after;

} elseif ( is_404() ) {

  echo $before . 'Error 404' . $after;

} if ( get_query_var('paged') ) {
  if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ' (';
  echo __('Page') . ' ' . get_query_var('paged');
    if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ')';
  }
  echo '</div>';
  }
}

// =================================
// Pagination
// =================================
function get_pagination($args = null) {
$defaults = array(
  'page' => null,
  'pages' => null, 
  'range' => 2,
  'gap' => 2,
  'anchor' => 1,
  'before' => '<ul class="pagination"><li class="pages">Pages</li>',
  'after' => '</ul>',
  'nextpage' => __('Next'),
  'previouspage' => __('Back'),
  'echo' => 1
);
$r = wp_parse_args($args, $defaults); extract($r, EXTR_SKIP);
if (!$page && !$pages) {
  global $wp_query;
  $page = get_query_var('paged');
  $page = !empty($page) ? intval($page) : 1;
  $posts_per_page = intval(get_query_var('posts_per_page'));
  $pages = intval(ceil($wp_query->found_posts / $posts_per_page));
}
$output = "";
if ($pages > 1) {	
  $output .= "$before";
  $ellipsis = "<li><span class=\"current-page\">...</span></li>";
if ($page > 1 && !empty($previouspage)) {
  $output .= "<li><a href='" . get_pagenum_link($page - 1) . "'>$previouspage</a></li>";
}
$min_links = $range * 2 + 1;
$block_min = min($page - $range, $pages - $min_links);
$block_high = max($page + $range, $min_links);
$left_gap = (($block_min - $anchor - $gap) > 0) ? true : false;
$right_gap = (($block_high + $anchor + $gap) < $pages) ? true : false;
if ($left_gap && !$right_gap) {
  $output .= sprintf('%s%s%s', 
  pagination(1, $anchor), 
  $ellipsis, 
  pagination($block_min, $pages, $page)
  );
}
else if ($left_gap && $right_gap) {
  $output .= sprintf('%s%s%s%s%s', 
  pagination(1, $anchor), 
  $ellipsis, 
  pagination($block_min, $block_high, $page), 
  $ellipsis, 
  pagination(($pages - $anchor + 1), $pages)
  );
}
else if ($right_gap && !$left_gap) {
  $output .= sprintf('%s%s%s', 
  pagination(1, $block_high, $page),
  $ellipsis,
  pagination(($pages - $anchor + 1), $pages)
  );
}
else {
  $output .= pagination(1, $pages, $page);
}
if ($page < $pages && !empty($nextpage)) {
  $output .= "<li><a href='" . get_pagenum_link($page + 1) . "'>$nextpage</a></li>";
}
$output .= $after;
}
if ($echo) {
  echo $output;
}
return $output;
}

function pagination($start, $max, $page = 0) {
$output = "";
for ($i = $start; $i <= $max; $i++) {
  $output .= ($page === intval($i)) 
  ? "<li><span class=\"current-page\">$i</span></li>" 
  : "<li><a href='" . get_pagenum_link($i) . "'>$i</a></li>";
}
return $output;
}