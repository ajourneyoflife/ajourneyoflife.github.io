<?php
// =================================
// About author
// =================================
class sf_author extends WP_Widget {
function sf_author() {
$widget_ops = array('description' => 'Show a short biography of author' );
parent::WP_Widget(false, "sF Blog Author",$widget_ops);      
}

function widget($args, $data) {  
extract( $args );
  $title = $data['title'];
  $bio = $data['bio'];
  $pic = $data['pic'];
  $read_more_text = $data['read_more_text'];
  $read_more_url = $data['read_more_url'];
?>

<?php echo $before_widget; ?>
<?php if ($title) { echo $before_title . $title . $after_title; } ?>

<?php if( $pic ); { ?><img src="<?php echo $pic; ?>" class="alignleft" alt="<?php echo $title; ?>" /><?php } ?>
<?php echo $bio; ?><?php if ( $read_more_url ) echo '<br /><a href="'.$read_more_url.'">'.$read_more_text.'</a>'; ?>
  

<?php echo $after_widget; }
function update($new_data, $old_data) {return $new_data;}
function form($data) {        
  $title = esc_attr($data['title']);
  $bio = esc_attr($data['bio']);
  $pic = esc_attr($data['pic']);
  $read_more_text = esc_attr($data['read_more_text']);
  $read_more_url = esc_attr($data['read_more_url']);
?>

<p>
  <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title',sf); ?>:</label>
  <input type="text" name="<?php echo $this->get_field_name('title'); ?>"  value="<?php echo $title; ?>" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('pic'); ?>"><?php _e('Picture',sf); ?>:</label>
  <input type="text" name="<?php echo $this->get_field_name('pic'); ?>"  value="<?php echo $pic; ?>" class="widefat" id="<?php echo $this->get_field_id('pic'); ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('bio'); ?>"><?php _e('Short Description',sf); ?>:</label>
  <textarea name="<?php echo $this->get_field_name('bio'); ?>" class="widefat" rows="5" id="<?php echo $this->get_field_id('bio'); ?>"><?php echo $bio; ?></textarea>
</p>
<p>
  <label for="<?php echo $this->get_field_id('read_more_text'); ?>"><?php _e('Read More Text (optional)',sf); ?>:</label>
  <input type="text" name="<?php echo $this->get_field_name('read_more_text'); ?>"  value="<?php echo $read_more_text; ?>" class="widefat" id="<?php echo $this->get_field_id('read_more_text'); ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('read_more_url'); ?>"><?php _e('Read More URL (optional)',sf); ?>:</label>
  <input type="text" name="<?php echo $this->get_field_name('read_more_url'); ?>"  value="<?php echo $read_more_url; ?>" class="widefat" id="<?php echo $this->get_field_id('read_more_url'); ?>" />
</p>
       
<?php } }
register_widget('sf_author');

// =================================
// Flickr
// =================================
class sF_flickr extends WP_Widget {
function sF_flickr() {
$widget_ops = array('description' => 'This Flickr widget.' );
parent::WP_Widget(false, "sF Flickr",$widget_ops);      
}
function widget($args, $data) {  
extract( $args );
  $title = $data['title'];
  $id = $data['id'];
  $number = $data['number'];
?>


<?php echo $before_widget; ?>

<?php if ($title) { echo $before_title . $title . $after_title; } ?>
<div class="flickr">
<script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count=<?php echo $number; ?>&amp;display=latest&amp;size=s&amp;layout=x&amp;source=user&amp;user=<?php echo $id; ?>"></script>        
</div>

<?php echo $after_widget;}
function update($new_data, $old_data) {return $new_data;}
function form($data) {        
$title = esc_attr($data['title']);
$id = esc_attr($data['id']);
$number = esc_attr($data['number']);
?>

<p>
  <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label>
  <input type="text" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $title; ?>" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('id'); ?>"><?php _e('Flickr ID (<a href="http://www.idgettr.com" target="_blank">idGettr</a>):'); ?></label>
  <input type="text" name="<?php echo $this->get_field_name('id'); ?>" value="<?php echo $id; ?>" class="widefat" id="<?php echo $this->get_field_id('id'); ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('number'); ?>"><?php _e('Number:'); ?></label>
  <select name="<?php echo $this->get_field_name('number'); ?>" class="widefat" id="<?php echo $this->get_field_id('number'); ?>">
    <?php for ( $i = 1; $i < 10; $i += 1) { ?>
    <option value="<?php echo $i; ?>" <?php if($number == $i){ echo "selected='selected'";} ?>><?php echo $i; ?></option>
    <?php } ?>
  </select>
</p>

<?php } }
register_widget('sF_flickr');

// =================================
// Social network
// =================================
class sF_social extends WP_Widget {
function sF_social() {
$widget_ops = array('description' => 'This widget shows your social networks' );
parent::WP_Widget(false, "sF Social Networks",$widget_ops);      
}

function widget($args, $data) {  
extract( $args );
  $title = $data['title'];
  $rss = $data['rss'];
  $facebook = $data['facebook'];
  $twitter = $data['twitter'];
?>

<?php echo $before_widget; ?>

<?php if ($title) { echo $before_title . $title . $after_title; } ?>

<div class="textwidget">
  <ul class="social-icons">
    <?php if( $twitter ) echo "<li><a href=\"http://www.twitter.com/$twitter\" class=\"social-twitter\">Twitter</a></li>" ?>
    <?php if( $facebook ) echo "<li><a href=\"$facebook\" class=\"social-facebook\">Facebook</a></li>" ?>
    <li><a href="<?php if( $rss ) { echo $rss; } else { echo bloginfo('rss2_url'); } ?>" class="social-rss">RSS feed</a></li>
  </ul>
</div>

<?php	 echo $after_widget;}
function update($new_data, $old_data) {return $new_data;}
function form($data) {        
  $title = esc_attr($data['title']);
  $rss = esc_attr($data['rss']);
  $facebook = esc_attr($data['facebook']);
  $twitter = esc_attr($data['twitter']);
?>

<p>
  <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label>
  <input type="text" name="<?php echo $this->get_field_name('title'); ?>"  value="<?php echo $title; ?>" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('rss'); ?>"><?php _e('Custom RSS feed (Leave blank to use default):'); ?></label>
  <input type="text" name="<?php echo $this->get_field_name('rss'); ?>"  value="<?php echo $rss; ?>" class="widefat" id="<?php echo $this->get_field_id('rss'); ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('facebook'); ?>"><?php _e('Facebook full URL:'); ?></label>
  <input type="text" name="<?php echo $this->get_field_name('facebook'); ?>"  value="<?php echo $facebook; ?>" class="widefat" id="<?php echo $this->get_field_id('facebook'); ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('twitter'); ?>"><?php _e('Twitter username:'); ?></label>
  <input type="text" name="<?php echo $this->get_field_name('twitter'); ?>"  value="<?php echo $twitter; ?>" class="widefat" id="<?php echo $this->get_field_id('twitter'); ?>" />
</p>

<?php } }
register_widget('sF_social');

// =================================
// Tweets
// =================================
class sF_tweet extends WP_Widget {
function sF_tweet() {
$widget_ops = array('description' => 'This widget shows your tweets' );
parent::WP_Widget(false, "sF Tweet",$widget_ops);      
}

function widget($args, $data) {  
extract( $args );
  $title = $data['title'];
  $twitter = $data['twitter'];
  $updates = $data['updates'];
?>

<?php echo $before_widget; ?>

<?php if ($title) { echo $before_title . $title . $after_title; } ?>

<div class="tweet">
<script type="text/javascript">
jQuery(document).ready(function($) {
$(".tweet").tweet({
  username: "<?php echo $twitter; ?>",
  count: <?php echo $updates; ?>,
  loading_text: "Loading tweets..."
});
})
</script>
</div>

<?php	 echo $after_widget;}
function update($new_data, $old_data) {return $new_data;}
function form($data) {        
  $title = esc_attr($data['title']);
  $twitter = esc_attr($data['twitter']);
  $updates = esc_attr($data['updates']);
?>

<p>
  <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label>
  <input type="text" name="<?php echo $this->get_field_name('title'); ?>"  value="<?php echo $title; ?>" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('twitter'); ?>"><?php _e('Twitter username:'); ?></label>
  <input type="text" name="<?php echo $this->get_field_name('twitter'); ?>"  value="<?php echo $twitter; ?>" class="widefat" id="<?php echo $this->get_field_id('twitter'); ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('updates'); ?>"><?php _e('Number of Twitter updates:'); ?></label>
  <select name="<?php echo $this->get_field_name('updates'); ?>" class="widefat" id="<?php echo $this->get_field_id('updates'); ?>">
    <?php for ( $i = 1; $i < 11; $i += 1) { ?>
    <option value="<?php echo $i; ?>" <?php if($updates == $i){ echo "selected='selected'";} ?>><?php echo $i; ?></option>
    <?php } ?>
  </select>
</p>

<?php } }
register_widget('sF_tweet');

// =================================
// Popular entries list (by comment)
// =================================
class sF_popular extends WP_Widget {
function sF_popular() {
$widget_ops = array('description' => 'This show a list of popular post according to comment received' );
parent::WP_Widget(false, "sF Popular Posts",$widget_ops);      
}

function widget($args, $data) {  
extract( $args );
  $title = $data['title'];
  $count = $data['count'];
?>

<?php echo $before_widget; ?>
<?php if ($title) { echo $before_title . $title . $after_title; } ?>
<ul>
<?php $popular = new WP_Query('orderby=comment_count&posts_per_page=' .$count . ''); ?>
<?php while ($popular->have_posts()) : $popular->the_post(); ?>
<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
<?php endwhile; wp_reset_query(); ?>
</ul>

<?php	 echo $after_widget;}
function update($new_data, $old_data) {return $new_data;}
function form($data) {        
  $title = esc_attr($data['title']);
  $count = esc_attr($data['count']);
?>

<p>Most popular show the most commented entries first</p>
<p>
  <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label>
  <input type="text" name="<?php echo $this->get_field_name('title'); ?>"  value="<?php echo $title; ?>" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" />
</p>
<p>
  <label for="<?php echo $this->get_field_id('count'); ?>"><?php _e('Number of post show:'); ?></label>
  <select name="<?php echo $this->get_field_name('count'); ?>" class="widefat" id="<?php echo $this->get_field_id('count'); ?>">
    <?php for ( $i = 1; $i < 10; $i += 1) { ?>
    <option value="<?php echo $i; ?>" <?php if($count == $i){ echo "selected='selected'";} ?>><?php echo $i; ?></option>
    <?php } ?>
  </select>
</p>

<?php } }
register_widget('sF_popular');