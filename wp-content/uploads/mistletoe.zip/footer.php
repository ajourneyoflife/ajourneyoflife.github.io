</div><!-- .container -->

<footer class="footer">
<div class="footer-inner">
<p class="footer-copy">
  <?php _e('Copyrighted',sf); ?> &copy; <?php echo date('Y'); ?> <a href="<?php echo get_option('home'); ?>"><?php bloginfo('name'); ?></a>. <?php _e('Powered by',sf); ?> <a href="http://www.wordpress.org">WordPress</a>. <a href="http://www.simplywp.net" class="footer-credit"><?php _e('Christmas holiday WordPress theme by',sf); ?> simplyWP</a>
</p>
</div>
</footer><!-- .footer -->

<!-- Javascript -->
  <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.mediaqueries.js"></script>
  <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.tweet.js"></script>
  <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.form.js"></script>
  <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/uniform/uniform.js"></script>
  <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jqueryslidemenu.js"></script>
  <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/swfobject.js"></script>
  <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/scripts.js"></script>
  <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
  <script>
    (function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) {return;}
    js = d.createElement(s); js.id = id;
    js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1&appId=120498914718362";
    fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
  </script>
<!-- Javascript -->

<?php wp_footer(); ?>
</body>
</html>