<?php
// INCLUDE WIDGETS AND META BOXES
$includes_path = TEMPLATEPATH . '/includes/';
include ($includes_path . 'custom_widgets.php');
include ($includes_path . 'modules.php');
include ($includes_path . 'shortcodes.php');
include ($includes_path . 'quicktags.php');
include ($includes_path . 'widgets.php');
?>