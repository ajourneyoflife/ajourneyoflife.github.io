// tooltip.js
// http://cssglobe.com/post/1695/easiest-tooltip-and-image-preview-using-jquery
//
this.tooltip=function(){xOffset=10;yOffset=20;jQuery("a.tooltip, span.tooltip").hover(function(a){this.t=this.title;this.title="";jQuery("body").append("<p id='tooltip'>"+this.t+"</p>");jQuery("#tooltip").css("top",a.pageY-xOffset+"px").css("left",a.pageX+yOffset+"px").fadeIn("fast")},function(){this.title=this.t;jQuery("#tooltip").remove()});jQuery("a.tooltip, span.tooltip").mousemove(function(a){jQuery("#tooltip").css("top",a.pageY-xOffset+"px").css("left",a.pageX+yOffset+"px")})};jQuery(document).ready(function(){tooltip()});


jQuery(document).ready(function($){ // START

  // Input title
  jQuery('input[title], textarea[title]').each(function() {if($(this).val() === '') {$(this).val($(this).attr('title'));}
    $(this).focus(function() {if($(this).val() == $(this).attr('title')) {$(this).val('').addClass('focused');}});
    $(this).blur(function() {if($(this).val() === '') {$(this).val($(this).attr('title')).removeClass('focused');}});
  });

  // Fade in and out
  jQuery('.fade').hover(
    function() {$(this).fadeTo("medium", 1);},
    function() {$(this).fadeTo("medium", 0.5);}
  );

  // Accordion
	jQuery('.accordion-content').hide();
	jQuery('.accordion-title').click(function() {
  jQuery('.accordion-content').slideUp('normal');
  jQuery('.accordion-title').removeClass('accordion-open');
    if($(this).next().is(':hidden') == true) {
      $(this).next().slideDown('normal');
      $(this).addClass('accordion-open');
    } 
  });

  // Uniform */
  jQuery(".uniform, .aside input, .aside textarea, .aside select, .aside button, .section input, .section textarea, .section select, .section button").uniform();

}); // END