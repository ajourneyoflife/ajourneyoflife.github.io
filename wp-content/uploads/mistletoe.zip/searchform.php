<form class="sideform" method="get" action="<?php bloginfo('siteurl'); ?>">
  <fieldset>
    <input type="text" name="s" class="sidetext" size="15" title="<?php _e('Search',sf); ?>" />
    <input type="submit" class="sidebutton" value="<?php _e('Search',sf); ?>" />
  </fieldset>
</form>