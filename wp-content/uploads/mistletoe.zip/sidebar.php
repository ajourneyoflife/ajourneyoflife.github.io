<aside class="aside">
  <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Right Sidebar') ) : endif; ?>
</aside><!-- .aside -->