<?php if ( !theme_dynamic_sidebar( 'top' ) ) : ?>
<?php $style = theme_get_option('theme_sidebars_style_top'); ?>



<?php endif; ?>