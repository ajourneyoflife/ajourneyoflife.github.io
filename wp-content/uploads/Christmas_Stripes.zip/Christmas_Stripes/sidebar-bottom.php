<?php if ( !theme_dynamic_sidebar('bottom') ) : ?>
<?php $style = theme_get_option('theme_sidebars_style_bottom'); ?>



<?php endif; ?>